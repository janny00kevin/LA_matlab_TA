function [Ainv] = GJinv(A)

tic
% 檢查輸入矩陣是否為方陣
[rows, cols] = size(A);
if rows ~= cols
    error('輸入矩陣不是方陣');
end

% 將矩陣擴展成增廣矩陣
augmented_matrix = [A, eye(rows)]; 

% 將增廣矩陣轉換成上三角形式
for i = 1:rows
    % 如果對角線元素為零，交換列以使其非零
    if augmented_matrix(i, i) == 0
        non_zero_row = find(augmented_matrix(i:rows, i),1) + 1;
        % 檢查矩陣是否是奇異矩陣
        if isempty(non_zero_row)
            error('矩陣是奇異矩陣，無法計算反矩陣');
        end
        augmented_matrix([i, non_zero_row], :) = augmented_matrix([non_zero_row, i], :);
    end
        
    % 使i列對角線元素為1
    augmented_matrix(i, :) = augmented_matrix(i, :) / augmented_matrix(i, i);

    % 利用列運算消除對角線以下的元素
    for j = i+1:rows
        augmented_matrix(j, :) = augmented_matrix(j, :) - augmented_matrix(j, i) * augmented_matrix(i, :);
    end
end

% 利用列運算消除對角線以上的元素
for i = rows:-1:2
    for j = i-1:-1:1
        augmented_matrix(j, :) = augmented_matrix(j, :) - augmented_matrix(j, i) * augmented_matrix(i, :);
    end
end

%得反矩陣
Ainv = augmented_matrix(:, cols+1:end);

toc

end