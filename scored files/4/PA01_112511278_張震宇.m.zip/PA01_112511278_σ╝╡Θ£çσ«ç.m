function Ainv = GJinvOptimized(A)
    [m, n] = size(A);

    if m ~= n
        error('Error: The matrix must be square for inversion.');
    end

    if m == 1 && n == 1
        if A(1, 1) == 0
            error('Error: The matrix is singular and cannot be inverted.');
        else
            Ainv = 1 / A(1, 1);
            return;
        end
    end

    augmented_matrix = [A eye(m)];

    for i = 1:m
        pivot_row = find(abs(augmented_matrix(i:end, i)) > eps, 1) + i - 1;

        if isempty(pivot_row)
            error('Error: The matrix is singular and cannot be inverted.');
        end

        augmented_matrix([i, pivot_row], :) = augmented_matrix([pivot_row, i], :);

        pivot_val = augmented_matrix(i, i);
        augmented_matrix(i, :) = augmented_matrix(i, :) / pivot_val;

        for j = 1:m
            if j ~= i
                factor = augmented_matrix(j, i);
                augmented_matrix(j, :) = augmented_matrix(j, :) - factor * augmented_matrix(i, :);
            end
        end
    end

    Ainv = augmented_matrix(:, m+1:end);
end