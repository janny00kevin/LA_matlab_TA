function [Ainv] = GJinv(A)
    if size(A, 1)~=size(A, 2)
        error("the matrix is a rectangular matrix");
    elseif (size(A, 1)==size(A, 2) && size(A, 1)==1)
        Ainv=1/A;
        return;
    end

    Ainv=A;
    Ainv(1:end,end+1:end+size(A,2))=eye(size(A,2));

    for i=1:size(A,1)-1
        if Ainv(i,i)<0.0000001    
            for j=i+1:size(A,1)       
                if abs(Ainv(j,i))>0.0000001
                    Ainv([i,j],:)=Ainv([j,i],:);             
                    break;
                end
            end
        end
        %disp(Ainv);
        E=eye(size(A,2));
        for j=i+1:size(A,1)
            if abs(Ainv(i,i))<0.0000001
                error("the matrix is not invertible");
            end
            E(j,i)=-(Ainv(j, i)/Ainv(i, i));
        end
        %disp(E);
        Ainv=E*Ainv;
    end
    
    P=eye(size(A,1));
    for i=1:size(A,1)
        if abs(Ainv(i,i))<0.0000001
            error("the matrix is not invertible");
        end
        P(i,i)=1/Ainv(i,i);
    end
    Ainv=P*Ainv;

    for i=1:size(A,1)
        E=eye(size(A,1));
   
        for j=i+1:size(A,1)
            if abs(Ainv(size(A,1)-i+1, size(A,1)-i+1))<0.0000001
                error("the matrix is not invertible");
            end
            E(size(A,1)-j+1,size(A,1)-i+1)=-(Ainv(size(A,1)-j+1, size(A,1)-i+1)/Ainv(size(A,1)-i+1, size(A,1)-i+1));
        end
        
        Ainv=E*Ainv;
 
    end
    %disp(Ainv);
    Ainv=Ainv(:, size(A,1)+1:end);
end