% Return the inverse of a matrix if the inverse exsist,
% otherwise throw an error 
function[Ainv] = GJinv(A)
    % Check if there is an input matrix
    narginchk(1, 1);
    if isscalar(A)
        Ainv = A;
        return;
    end
    % Return error message if the matrix is not a square matrix
    if size(A, 1) ~= size(A, 2)
        error("This is not a square matrix, thus not invertible!");
        return;
    end
    % Set a samll value to approximate 0
    e = 0.00001;
    [numRow, numCol] = size(A);
    % Make an augmented matrix from A
    Ainv = [A, eye(numRow)];

    for pivot = 1:numRow
        % Check pivot, if 0, "permute"
        needPermute = false;
        if abs(Ainv(pivot, pivot)) <= e
            needPermute = true;
        end
        permuteRow = pivot + 1
        while needPermute && permuteRow <= numRow ...
                && abs(Ainv(permuteRow, pivot)) <= e
            permuteRow = permuteRow + 1;
        end
        % If permuteRow > numRow, throw error and return
        if needPermute && permuteRow > numRow
            error("Matrix not invertible!");
            return;
        end
        % Perform permutation
        if needPermute
            Ainv([pivot, permuteRow], :) = Ainv([permuteRow, pivot], :);
        end
        elimRow = pivot + 1;
        % Do "Gaussian Elimination"
        % Normalize pivot to 1
        Ainv(pivot, :) = Ainv(pivot, :)/Ainv(pivot, pivot);
        % Make a copy row pivotRow
        pivotRow = Ainv(pivot, :);
        for row = elimRow : numRow
            if abs(Ainv(row, pivot)) > e
                Ainv(row, :) = Ainv(row, :) - Ainv(row, pivot) * pivotRow;
            end
            % If the whole row == 0, throw error and return
            if all(abs(Ainv(row, 1:numCol)) <= e)
                error("Matrix not invertible!");
                return;
            end
        end
    end
    % Do "Back substitution"/ "GJ"
    for pivot = numRow:-1:1
        % Make a copy of pivot row
        pivotRow = Ainv(pivot, :);
        elimRow = pivot - 1;
        for row = elimRow:-1:1
            if abs(Ainv(row, pivot)) > e
                Ainv(row, :) = Ainv(row, :) - Ainv(row, pivot) * pivotRow;
            end
        end
    end
    Ainv = Ainv(:, numCol+1:end);
end