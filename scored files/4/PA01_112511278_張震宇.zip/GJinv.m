function Ainv = GJinv(A)
    [m, n] = size(A);

    if m ~= n
        error('Error: The matrix must be square for inversion.');
    end

    if m == 1 && n == 1
        if A(1, 1) == 0
            error('Error: The matrix is singular and cannot be inverted.');
        else
            Ainv = 1 / A(1, 1);
            return;
        end
    end

    aug = [A eye(m)];

    for i = 1:m
        pivrow = find(abs(aug(i:end, i)) > eps, 1) + i - 1;

        if isempty(pivrow)
            error('Error: The matrix is singular and cannot be inverted.');
        end

        aug([i, pivrow], :) = aug([pivrow, i], :);

        pivval = aug(i, i);
        aug(i, :) = aug(i, :) / pivval;

        for j = 1:m
            if j ~= i
                factor = aug(j, i);
                aug(j, :) = aug(j, :) - factor * aug(i, :);
            end
        end
    end

    Ainv = aug(:, m+1:end);
end