function [Ainv] = GJinv(A)

%A=input('Please input your matrix:')

%A=[1 2 3 3;2 4 5 4; 3 5 6 5; 7 8 9 6];
%A=[1 2 3; 2 4 5; 3 5 6];
%A=[1 2 3; 2 4 5; -4 -8 -10];
%A=[0 0 -2; 2 4 -10; 2 4 -5];
x=size(A);
x1=x(1,1);
x2=x(1,2);

% Produce the identity matrix.
II=eye(size(A));
A1=A;

% If A(1,1)==0, swap the rows.
if A(1,1)==0
    [yr,yc]=find(A,1);
    A1([1,yr],:)= A1([yr,1],:);
    II([1,yr],:)= II([yr,1],:);
end
    
while(1)

% Judge if the matrix is square.
if (x1~=x2) 
    sprintf('%s','This is not a square matrix.')
    break
end

for pp=1:x1-1
    if A1(pp,pp)==0
           [r,c]=find(A1(pp+1,:),(x1-pp+1),'last');
        
           if c(pp-1)==pp
            A1([pp,pp+1],:)= A1([pp+1,pp],:);
            II([pp,pp+1],:)= II([pp+1,pp],:);
            for i=1:(x1-pp)     
                 m(pp,i)=-(A1(i+pp,pp)/A1(pp,pp));
                 B(i+pp,:)=A1(pp,:)*m(pp,i);
                 IB(i+pp,:)=II(pp,:)*m(pp,i);
                 A1(i+pp,:)=A1(i+pp,:)+B(i+pp,:);
                 II(i+pp,:)=II(i+pp,:)+IB(i+pp,:);  
            end
          
           else
                A1=A1;
           end
    else 
            for i=1:(x1-pp)     
                 m(pp,i)=-(A1(i+pp,pp)/A1(pp,pp));
                 B(i+pp,:)=A1(pp,:)*m(pp,i);
                 IB(i+pp,:)=II(pp,:)*m(pp,i);
                 A1(i+pp,:)=A1(i+pp,:)+B(i+pp,:);
                 II(i+pp,:)=II(i+pp,:)+IB(i+pp,:);  
             end
    end
      
    
end
C=A1

%To check if det(A)==0.    
    tt=prod(diag(C)); %Find the diagonal elements of matrix C.
    epslon=1*10^(-6);
    
if abs(tt)<=epslon
        sprintf('%s','The matrix is non-invertible') 
    break
end
        
     A2=C; 
     I2=II;

%To find the diagonal matrix A2.
for u=1:(x1-1)
        rr(u)=x1-u+1;   
        for k=1:(x1-u)
            n(u,k)=-(A2(rr(u)-k,rr(u))/A2(rr(u),rr(u)));
            F((rr(u)-k),:)=A2(rr(u),:)*n(u,k);
            IC(rr(u)-k,:)=I2(rr(u),:)*n(u,k);
            A2((rr(u)-k),:)=F((rr(u)-k),:)+A2((rr(u)-k),:);
            I2(rr(u)-k,:)=IC((rr(u)-k),:)+I2((rr(u)-k),:);
        end
end

       
        JJ=A2;
        matrixinv=I2;

%To make each diagonal elements of the matrix JJ equal to 1. 
        for w=1:x1
        matrixinv(w,:)=matrixinv(w,:)./JJ(w,w);
        end
        
%Print the final results inv(A).   
sprintf('The inverse of the matrix is:')
matrixinv
break
end
