function A = swapRows(A, i, j)
    temp = A(i, :);
    A(i, :) = A(j, :);
    A(j, :) = temp;
end

