function [index] = find_nonzero_row(matrix, colIndex, dir)

  a=length(matrix);
if dir == 1
    for j = colIndex:a
        if   matrix(colIndex,j ) ~= 0
            index = j;
            return;
        end
    end
end
if dir == 0
    for j = colIndex:-1:1
        if matrix(colIndex,j ) ~= 0
            index = j;
            return;
        end
    end
end
index = 37814; %some random code to exit with it, when we can't find next nonzero row
end