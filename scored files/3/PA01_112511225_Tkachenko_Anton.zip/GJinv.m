
input = A;
[i, j] = size(input);
if i~=j
    error('Matrix is not square!');
end
fprintf("my inverse:\n")
disp(inverse(input));

fprintf("matlab inverse:\n")
 disp(inv(input));






