function multiplyRowByScale(A, i, k)
  if i <= 0 || i > size(A, 1)
    error('invalid row index');
  end
  A(i,:) = A(i,:) .* k;
  disp(A(i,:));
end