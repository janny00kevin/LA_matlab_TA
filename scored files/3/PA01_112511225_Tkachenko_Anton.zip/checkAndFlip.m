function aug_matrix = checkAndFlip(Matrix, i)
    Matrix(i, :) = Matrix(i, :) * -1;
aug_matrix = Matrix;
end
