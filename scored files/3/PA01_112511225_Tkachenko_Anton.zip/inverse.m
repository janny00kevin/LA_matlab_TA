function A_inverse=inverse(A)
  a=length(A); 
I=eye(a);
aug_matrix=[A I]; %creating my augmented matrix
code_for_singular = 0; %some special code to exit with it, in case of singular matrix
for i=1:a-1
    for j=i+1:a
            %Changing sign of whole row
        if aug_matrix(i, i) < 0
            aug_matrix = checkAndFlip(aug_matrix, i);
        end

        %Swapping rows
        if aug_matrix(i, i) == 0
            for_swap = find_nonzero_row(aug_matrix, i, 1);
            if for_swap == 37814
                
                aug_matrix(:) = Inf;
                break;
            end
            aug_matrix = swapRows(aug_matrix, i, for_swap);
        end
     
        aug_matrix(j, :) = aug_matrix(j, :)*aug_matrix(i,i) - aug_matrix(i, :)*aug_matrix(j, i);
        
    end
end
%end of back substitution


for k = a:-1:2
    for g=k-1:-1:1

        if aug_matrix(k, k) < 0
            aug_matrix = checkAndFlip(aug_matrix, k);
        end
        if aug_matrix(k, k) == 0
            for_swap = find_nonzero_row(aug_matrix, k, 0);
            if for_swap == 37814
                code_for_singular = 1;
                aug_matrix(:) = Inf;
                break;
            end
            aug_matrix = swapRows(aug_matrix, k, for_swap);
        end

        aug_matrix(g, :) = aug_matrix(g, :)*aug_matrix(k,k) - aug_matrix(k, :)*aug_matrix(g, k);

    end
end



    %Doing GCD(Greatest common divisor)
for i = 1:a
    if code_for_singular == 1
        break;
    end
    RowForGCD = sym(aug_matrix(i, :));
    G = gcd(RowForGCD);

    aug_matrix(i,:) = RowForGCD ./ G;
end


%Make pivot 1 by dividing whole row by pivot
for i=1:a
    aug_matrix(i, :) = aug_matrix(i, :) ./ aug_matrix(i, i);
end
    if code_for_singular == 1
        aug_matrix(:)  = Inf;
    end
A_inverse=aug_matrix(:,a+1:2*a);
end